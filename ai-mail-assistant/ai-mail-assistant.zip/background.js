browser.runtime.onInstalled.addListener(() => {
  console.log("AI Mail Assistant installiert.");
});
