---
name: New prompt
description: New prompt
invokable: true
---

Please write a thorough suite of unit tests for this code, making sure to cover all relevant edge cases